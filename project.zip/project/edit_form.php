<html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="css/style.css"/>
	
</head>
<body>

<div class="container-fluid">
<div id="edit">
	<h1>Update info----</h1>
	<br>
<?php
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'logintable');
$id = intval($_GET['id']);

if($id == 0){
	header('location: product_list.php');
}

$sql = "SELECT * FROM info where id = {$id}";
$result = $con->query($sql);
$row = $result->fetch_assoc();

?>

<form action="update.php?id=<?php echo $id; ?>" method="POST">
<br>
Name: 
<input type="text" name="user" 
value="<?php echo $row['name']; ?>" required>
<br><br>
password: 
<input type="text" name="pass" 
value="<?php echo $row['pass']; ?>" required>
<br><br>
<div class="btn">
<button type="submit" name="edit" value="Update">Update</button>
</div>
</form>
</div></div>
</body>
</html>