<html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="css/style.css"/>

    <title>login</title>
</head>
<body>
<div class="container-fluid">
      
<div id="navbar">
<nav >
    <ul class="nav ">
        <li>
            <a href="index.html">Home</a>
        </li>
       <li>
            <a class="nav-link" href="login.php">Login</a>
        </li>
        <li>
        <a class="nav-link " href="shope.html ">Shope</a>
        </li>
    </ul>
</nav>
</div>

<br><br>

<div class="login" >
<h1>Login Here----</h1>
<br>
    <form action="insert.php" method="post">
    <br><br>
        Username: <input type="text" name="user" required> <br><br> 
        Password: <input type="password" name="pass" required><br><br>
        <div class="btn">
      <button  type="submit" name="btn">login</button>
</div>
    </form>
</div>
    </div>
 
</body>

</html>