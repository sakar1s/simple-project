<?php
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'logintable');

$id = $_GET['id'];

// sql to delete a record
$sql = "DELETE FROM info WHERE id = {$id} limit 1";

if ($con->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('location: product_list.php?status=success');
} else {
    echo "Error deleting record: " . $con->error;
}

?>