

<?php
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'logintable');
$id = intval($_GET['id']);

if($id > 0){
	header('location: list_info.php');
}

if( isset($_POST['edit'])){
	$uname = $_POST['user'];
	$upass = $_POST['pass'];


	$update = "UPDATE info 
			SET name = '$uname', 
			pass = '$upass', 
			WHERE id = $id
			LIMIT 1";

	if ($con->query($update) === TRUE) {
		echo "Record updated successfully.";
	} else {
		echo "Error: " . $update . "<br>" . $con->error;
	}
	
} else {
	header('location:list_info.php');
}

?>
