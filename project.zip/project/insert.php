<?php
session_start();
header('location:list_info.php');
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'logintable');
	$uname = $_POST['user'];
	$upass = $_POST['pass'];

	$s="select * form info where name ='$uname'";

	$result = mysqli_query($con,$s);
	
		$log="insert into info(name,pass) values('$uname','$upass')";
		mysqli_query($con,$log);
		echo"login successfull";
	
	?>
