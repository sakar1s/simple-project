
<html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="css/style.css"/>
	<title>Logined Users</title>
</head>
<body>

<div class="container-fluid ">
<div id="login_list">
          
		<h1>logined users-----</h1>
		<br>
		<hr>
		<br>
		<table>
			<thead>
				<tr>
					<th>ID</th>
					<th>Email</th>
					<th>password</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>

<?php

if( isset($_GET['status']) && $_GET['status'] === "success") {
	echo "Operation was successful!";
}
	$con=mysqli_connect('localhost','root','');
	mysqli_select_db($con,'logintable');
	$sql = "SELECT * FROM info ";
	$result = $con->query($sql);
	if ($result->num_rows > 0) {
	    // output data of each row
	    while($row = $result->fetch_assoc()) {
	        echo "<tr>";
		        echo "<td>{$row['id']}</td>";
		        echo "<td>{$row['name']}</td>";
		        echo "<td>{$row['pass']}</td>";
		     

echo "<td><a href=\"edit_form.php?id={$row['id']}\">Edit</a></td>";
	
echo "<td><a href=\"delete.php?id={$row['id']}\">delete</a></td>";
	
	        echo "<tr/>";
	    }
	} else {
	    echo "0 results";
	}
?>
			</tbody>
		</table>

</div></div>
</body>
</html>